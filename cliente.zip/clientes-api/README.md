# clientes-api
API REST desenvolvida com Spring Boot para cadastro, edição e remoção de clientes.
